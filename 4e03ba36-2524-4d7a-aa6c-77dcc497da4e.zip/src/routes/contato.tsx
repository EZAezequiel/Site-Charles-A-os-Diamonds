import { createFileRoute } from "@tanstack/react-router";
import { Instagram, Mail, MapPin, MessageCircle, Phone, FileText } from "lucide-react";
import { Button } from "@/components/ui/button";
import { LeadForm } from "@/components/site/LeadForm";
import { PageHero, SectionTitle } from "@/components/site/parts";
import { img } from "@/data/catalog";
import { breadcrumbLd, COMPANY, MAP_QUERY, seo, whatsappUrl } from "@/lib/site";

export const Route = createFileRoute("/contato")({
  head: () => ({
    ...seo({
      title: "Contato | AÇOS DIAMONDS — Aço Inox Sob Medida",
      description: "Fale com a AÇOS DIAMONDS pelo WhatsApp (11) 91364-4273, telefone (11) 2467-1676 ou e-mail. Vila Nova Bonsucesso, CEP 07175-060.",
      path: "/contato",
    }),
    scripts: [breadcrumbLd([{ name: "Início", path: "/" }, { name: "Contato", path: "/contato" }])],
  }),
  component: Contato,
});

function Contato() {
  const items = [
    { icon: MapPin, label: "Endereço", value: `${COMPANY.street}, ${COMPANY.district} — CEP ${COMPANY.cep}`, href: `https://www.google.com/maps/search/?api=1&query=${MAP_QUERY}` },
    { icon: MessageCircle, label: "WhatsApp", value: COMPANY.phone1, href: whatsappUrl() },
    { icon: Phone, label: "Telefone", value: COMPANY.phone2, href: `tel:${COMPANY.phone2Tel}` },
    { icon: Mail, label: "E-mail", value: COMPANY.email, href: `mailto:${COMPANY.email}` },
    { icon: Instagram, label: "Instagram", value: COMPANY.instagram, href: COMPANY.instagramUrl },
    { icon: FileText, label: "CNPJ", value: COMPANY.cnpj },
  ];
  return (
    <>
      <PageHero image={img("fabrica-interior")} alt="Fábrica AÇOS DIAMONDS"
        crumbs={[{ label: "Início", to: "/" }, { label: "Contato" }]}
        eyebrow="Fale com a AÇOS DIAMONDS" title="Contato"
        text="Nossa equipe está pronta para desenvolver a solução ideal para sua necessidade.">
        <Button asChild variant="whatsapp" size="xl"><a href={whatsappUrl()} target="_blank" rel="noopener noreferrer"><MessageCircle /> WhatsApp</a></Button>
        <Button asChild variant="outlineLight" size="xl"><a href={`tel:${COMPANY.phone1Tel}`}><Phone /> Ligar agora</a></Button>
      </PageHero>
      <section className="container-site grid gap-10 py-16 lg:grid-cols-2 md:py-20">
        <div>
          <SectionTitle eyebrow="Canais de atendimento" title="Informações de contato" />
          <ul className="mt-8 grid gap-3 sm:grid-cols-2">
            {items.map((it) => {
              const inner = (
                <>
                  <it.icon className="size-6 shrink-0 text-primary" strokeWidth={1.5} />
                  <span><span className="block font-display text-xs font-bold uppercase tracking-wider text-muted-foreground">{it.label}</span>
                  <span className="break-words text-sm font-medium">{it.value}</span></span>
                </>
              );
              return (
                <li key={it.label}>
                  {it.href ? (
                    <a href={it.href} target={it.href.startsWith("http") ? "_blank" : undefined} rel="noopener noreferrer" className="flex h-full gap-3 rounded-lg border bg-card p-4 shadow-card transition hover:border-primary">{inner}</a>
                  ) : <div className="flex h-full gap-3 rounded-lg border bg-card p-4">{inner}</div>}
                </li>
              );
            })}
          </ul>
          <iframe title="Mapa — AÇOS DIAMONDS" loading="lazy" className="mt-6 aspect-[4/3] w-full rounded-lg border"
            src={`https://www.google.com/maps?q=${MAP_QUERY}&output=embed`} referrerPolicy="no-referrer-when-downgrade" />
        </div>
        <div>
          <SectionTitle eyebrow="Envie uma mensagem" title="Formulário de contato" />
          <div className="mt-8"><LeadForm kind="contato" /></div>
        </div>
      </section>
    </>
  );
}
