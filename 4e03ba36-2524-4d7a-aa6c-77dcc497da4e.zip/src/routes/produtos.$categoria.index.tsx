import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { CtaBand, PageHero, ProductCard, SectionTitle } from "@/components/site/parts";
import { categories, getCategory, productsOf } from "@/data/catalog";
import { breadcrumbLd, seo } from "@/lib/site";

export const Route = createFileRoute("/produtos/$categoria/")({
  loader: ({ params }) => {
    const category = getCategory(params.categoria);
    if (!category) throw notFound();
    return { category };
  },
  head: ({ loaderData, params }) => {
    if (!loaderData) return { meta: [{ title: "Categoria não encontrada | AÇOS DIAMONDS" }, { name: "robots", content: "noindex" }] };
    const c = loaderData.category;
    return {
      ...seo({ title: c.seoTitle, description: c.seoDescription, path: `/produtos/${params.categoria}` }),
      scripts: [breadcrumbLd([{ name: "Início", path: "/" }, { name: "Produtos", path: "/produtos" }, { name: c.name, path: `/produtos/${c.slug}` }])],
    };
  },
  component: CategoryPage,
});

function CategoryPage() {
  const { category: c } = Route.useLoaderData();
  const items = productsOf(c.slug);
  const special = c.slug === "projetos-especiais";
  return (
    <>
      <PageHero image={c.hero} alt={`${c.name} em aço inox`}
        crumbs={[{ label: "Início", to: "/" }, { label: "Produtos", to: "/produtos" }, { label: c.name }]}
        eyebrow={c.tagline} title={c.name} text={c.intro}>
        <Button asChild variant="hero" size="xl">
          {special ? <Link to="/projetos-especiais">Desenvolva seu projeto conosco</Link>
            : <Link to="/orcamento" search={{ segmento: c.name }}>Solicitar orçamento</Link>}
        </Button>
      </PageHero>
      <section className="border-b bg-card">
        <ul className="container-site flex flex-wrap gap-x-8 gap-y-3 py-6">
          {c.highlights.map((h) => (
            <li key={h} className="flex items-center gap-2 font-display text-xs font-bold uppercase tracking-wider">
              <CheckCircle2 className="size-4 text-primary" /> {h}
            </li>
          ))}
        </ul>
      </section>
      <section className="container-site py-16 md:py-20">
        <SectionTitle eyebrow="Linha de produtos" title={`${c.name} em aço inox`} />
        <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {items.map((p) => <ProductCard key={p.slug} p={p} />)}
        </div>
        {c.applications && (
          <div className="mt-14 rounded-lg border bg-card p-6 md:p-8">
            <h2 className="font-display text-lg font-bold uppercase">Aplicações</h2>
            <ul className="mt-4 flex flex-wrap gap-2">
              {c.applications.map((a) => <li key={a} className="rounded-full bg-muted px-4 py-2 text-sm">{a}</li>)}
            </ul>
          </div>
        )}
      </section>
      <section className="container-site pb-16">
        <h2 className="font-display text-sm font-bold uppercase text-muted-foreground">Outras categorias</h2>
        <div className="mt-4 flex flex-wrap gap-2">
          {categories.filter((o) => o.slug !== c.slug).map((o) => (
            <Link key={o.slug} to="/produtos/$categoria" params={{ categoria: o.slug }} className="rounded-md border bg-card px-4 py-2.5 text-sm font-medium hover:border-primary hover:text-primary">{o.name}</Link>
          ))}
        </div>
      </section>
      <CtaBand />
    </>
  );
}
