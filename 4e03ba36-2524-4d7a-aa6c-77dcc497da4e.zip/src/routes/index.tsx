import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Diamond } from "lucide-react";
import { DIFERENCIAIS } from "@/data/diferenciais";
import { Button } from "@/components/ui/button";
import { CtaBand, SectionTitle } from "@/components/site/parts";
import { categories, img } from "@/data/catalog";
import { seo } from "@/lib/site";

export const Route = createFileRoute("/")({
  head: () =>
    seo({
      title: "AÇOS DIAMONDS | Equipamentos e Móveis em Aço Inox Sob Medida",
      description:
        "Fabricante de equipamentos hospitalares, mobiliário, cozinhas industriais e projetos especiais em aço inox. Corte a laser, dobra CNC e solda laser.",
      path: "/",
    }),
  component: Home,
});


function Home() {
  return (
    <>
      <section className="section-dark relative overflow-hidden">
        <img src={img("hero-solda-laser")} alt="Soldagem a laser em aço inox" className="absolute inset-0 h-full w-full object-cover opacity-70" />
        <div className="hero-fade absolute inset-0" />
        <div className="container-site relative flex min-h-[78vh] flex-col justify-center py-16 md:py-24">
          <p className="eyebrow animate-rise">Excelência em aço inox desde 2017</p>
          <h1 className="mt-4 max-w-3xl text-4xl font-extrabold uppercase leading-[1.05] animate-rise md:text-6xl">
            Engenharia, tecnologia e <span className="text-steel">excelência</span> em aço inox.
          </h1>
          <p className="mt-6 max-w-xl text-base text-navy-foreground/80 md:text-lg">
            Desenvolvemos soluções em aço inox sob medida, unindo tecnologia, precisão e qualidade para atender aos mais diversos segmentos industriais e institucionais.
          </p>
          <div className="mt-9 flex flex-col gap-3 sm:flex-row">
            <Button asChild variant="hero" size="xl"><Link to="/segmentos">Conheça nossas soluções</Link></Button>
            <Button asChild variant="outlineLight" size="xl"><Link to="/orcamento">Solicite um orçamento</Link></Button>
          </div>
        </div>
      </section>

      <section className="container-site py-16 md:py-24">
        <SectionTitle eyebrow="Nossos diferenciais" title="Tecnologia em cada etapa" />
        <div className="mt-10 grid grid-cols-2 gap-px overflow-hidden rounded-lg border bg-border md:grid-cols-3">
          {DIFERENCIAIS.map((d) => (
            <div key={d.title} className="bg-card p-5 md:p-8">
              <d.icon className="size-8 text-primary" strokeWidth={1.5} />
              <h3 className="mt-4 font-display text-sm font-bold uppercase md:text-base">{d.title}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{d.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="section-dark py-16 md:py-24">
        <div className="container-site">
          <SectionTitle light eyebrow="Segmentos atendidos" title="Soluções para cada ambiente" text="Equipamentos e mobiliário em aço inox para hospitais, clínicas, laboratórios, cozinhas industriais e indústrias." />
          <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {categories.map((c) => (
              <Link key={c.slug} to="/produtos/$categoria" params={{ categoria: c.slug }}
                className="group relative flex min-h-80 flex-col justify-end overflow-hidden rounded-lg border border-navy-foreground/10">
                <img src={c.hero} alt={`${c.name} — soluções em aço inox`} loading="lazy" className="absolute inset-0 h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" />
                <div className="absolute inset-0 bg-gradient-to-t from-navy via-navy/70 to-transparent" />
                <div className="relative p-6">
                  <h3 className="text-xl font-extrabold uppercase">{c.name}</h3>
                  <p className="mt-2 text-sm text-navy-foreground/80">{c.short}</p>
                  <span className="mt-4 inline-flex items-center gap-1 font-display text-xs font-bold uppercase tracking-wider text-cyan">
                    Conhecer soluções <ArrowRight className="size-3.5 transition-transform group-hover:translate-x-1" />
                  </span>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className="container-site grid items-center gap-10 py-16 md:grid-cols-2 md:py-24">
        <div>
          <SectionTitle eyebrow="Quem somos" title="Excelência em aço inox desde 2017." />
          <p className="mt-5 text-muted-foreground">
            Desenvolvemos soluções em aço inox sob medida, com qualidade, precisão e agilidade para cada projeto. Atuamos no desenvolvimento e fabricação de equipamentos e estruturas que atendem às necessidades de diferentes segmentos.
          </p>
          <Button asChild variant="solid" size="xl" className="mt-8"><Link to="/sobre">Conheça a empresa</Link></Button>
        </div>
        <img src={img("hero-industria")} alt="Instalação industrial com tanques em aço inox" loading="lazy" className="aspect-[4/3] w-full rounded-lg object-cover shadow-card" />
      </section>

      <section className="section-dark grid-lines relative overflow-hidden">
        <div className="container-site grid items-center gap-10 py-16 md:grid-cols-2 md:py-24">
          <img src={img("linha-de-moagem")} alt="Linha de moagem em aço inox fabricada sob medida" loading="lazy" className="order-last w-full rounded-lg bg-card p-6 md:order-first" />
          <div>
            <Diamond className="size-8 text-cyan" strokeWidth={1.5} />
            <SectionTitle light eyebrow="Projetos especiais" title="Seu projeto, nossa engenharia." text="Transformamos necessidades em soluções industriais. Desenvolvemos equipamentos, estruturas e projetos personalizados de acordo com as especificações de cada cliente." />
            <Button asChild variant="hero" size="xl" className="mt-8"><Link to="/projetos-especiais">Solicitar projeto personalizado</Link></Button>
          </div>
        </div>
      </section>

      <CtaBand />
    </>
  );
}
