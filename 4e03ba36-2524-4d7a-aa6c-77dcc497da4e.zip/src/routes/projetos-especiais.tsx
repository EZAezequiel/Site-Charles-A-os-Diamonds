import { createFileRoute } from "@tanstack/react-router";
import { Cog, PencilRuler, Factory, Wrench } from "lucide-react";
import { Button } from "@/components/ui/button";
import { LeadForm } from "@/components/site/LeadForm";
import { PageHero, ProductCard, SectionTitle } from "@/components/site/parts";
import { img, productsOf } from "@/data/catalog";
import { breadcrumbLd, seo } from "@/lib/site";

export const Route = createFileRoute("/projetos-especiais")({
  head: () => ({
    ...seo({
      title: "Projetos Especiais em Aço Inox Sob Medida | AÇOS DIAMONDS",
      description: "Fabricação de equipamentos industriais em aço inox sob medida. Envie seu projeto ou desenho técnico: esteiras, túneis, tanques, linhas de moagem e mais.",
      path: "/projetos-especiais",
    }),
    scripts: [breadcrumbLd([{ name: "Início", path: "/" }, { name: "Projetos especiais", path: "/projetos-especiais" }])],
  }),
  component: Projetos,
});

const ETAPAS = [
  { icon: PencilRuler, t: "Entendimento", d: "Analisamos sua necessidade, especificações e desenhos técnicos." },
  { icon: Cog, t: "Engenharia", d: "Desenvolvemos a solução de acordo com a operação do cliente." },
  { icon: Factory, t: "Fabricação", d: "Corte a laser, dobra CNC e solda laser em aço inox." },
  { icon: Wrench, t: "Entrega", d: "Equipamento pronto para a rotina da sua operação." },
];

function Projetos() {
  return (
    <>
      <PageHero image={img("solucoes-especiais-hero")} alt="Tanques industriais em aço inox"
        crumbs={[{ label: "Início", to: "/" }, { label: "Projetos especiais" }]}
        eyebrow="Soluções especiais" title="Seu projeto, nossa engenharia."
        text="Transformamos necessidades em soluções industriais. Desenvolvemos equipamentos, estruturas e projetos personalizados de acordo com as especificações de cada cliente.">
        <Button asChild variant="hero" size="xl"><a href="#formulario">Desenvolva seu projeto conosco</a></Button>
      </PageHero>
      <section className="section-dark grid-lines border-t border-navy-foreground/10 py-14">
        <div className="container-site grid grid-cols-2 gap-6 md:grid-cols-4">
          {ETAPAS.map((e, i) => (
            <div key={e.t}>
              <span className="font-display text-xs font-bold text-cyan">0{i + 1}</span>
              <e.icon className="mt-2 size-8 text-cyan" strokeWidth={1.5} />
              <h2 className="mt-3 font-display text-sm font-bold uppercase">{e.t}</h2>
              <p className="mt-1 text-sm text-navy-foreground/70">{e.d}</p>
            </div>
          ))}
        </div>
      </section>
      <section className="container-site py-16 md:py-20">
        <SectionTitle eyebrow="Equipamentos desenvolvidos" title="Equipamentos industriais em aço inox" />
        <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {productsOf("projetos-especiais").map((p) => <ProductCard key={p.slug} p={p} />)}
        </div>
      </section>
      <section id="formulario" className="bg-muted py-16 md:py-20 scroll-mt-20">
        <div className="container-site grid gap-10 lg:grid-cols-[2fr_3fr]">
          <SectionTitle eyebrow="Solicitação de projeto" title="Desenvolva seu projeto conosco" text="Conte sua necessidade e, se tiver, anexe desenhos técnicos, fotos ou arquivos. Nossa equipe retornará o contato." />
          <LeadForm kind="projeto" withFiles defaultSegment="Projetos Especiais" />
        </div>
      </section>
    </>
  );
}
