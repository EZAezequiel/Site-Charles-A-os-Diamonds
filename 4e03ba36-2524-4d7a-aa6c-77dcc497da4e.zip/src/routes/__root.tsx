import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
  type ErrorComponentProps,
} from "@tanstack/react-router";
import { useEffect, type ReactNode } from "react";

import appCss from "../styles.css?url";
import { reportLovableError } from "../lib/lovable-error-reporting";
import { SiteHeader } from "@/components/site/SiteHeader";
import { SiteFooter } from "@/components/site/SiteFooter";
import { WhatsAppFloat } from "@/components/site/parts";
import { Button } from "@/components/ui/button";
import { COMPANY, SITE_URL } from "@/lib/site";

function NotFoundComponent() {
  return (
    <section className="section-dark grid-lines flex min-h-[70vh] items-center">
      <div className="container-site py-20 text-center">
        <p className="eyebrow">Erro 404</p>
        <h1 className="mt-3 text-3xl font-extrabold uppercase md:text-5xl">Página não encontrada</h1>
        <p className="mx-auto mt-4 max-w-md text-navy-foreground/75">
          A página que você procura não existe ou foi movida. Conheça nossos produtos em aço inox.
        </p>
        <div className="mt-8 flex flex-col justify-center gap-3 sm:flex-row">
          <Button asChild variant="hero" size="xl"><Link to="/produtos">Ver produtos</Link></Button>
          <Button asChild variant="outlineLight" size="xl"><Link to="/">Página inicial</Link></Button>
        </div>
      </div>
    </section>
  );
}

function ErrorComponent({ error, reset }: ErrorComponentProps) {
  console.error(error);
  const router = useRouter();
  useEffect(() => {
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold">Esta página não carregou</h1>
        <p className="mt-2 text-sm text-muted-foreground">Algo deu errado. Tente novamente.</p>
        <div className="mt-6 flex justify-center gap-2">
          <Button onClick={() => { router.invalidate(); reset(); }}>Tentar novamente</Button>
          <Button asChild variant="outline"><a href="/">Início</a></Button>
        </div>
      </div>
    </div>
  );
}

const orgLd = {
  "@context": "https://schema.org",
  "@type": ["Organization", "LocalBusiness"],
  name: COMPANY.name,
  url: SITE_URL,
  slogan: "Excelência em aço inox",
  foundingDate: "2017",
  email: COMPANY.email,
  telephone: [COMPANY.phone1Tel, COMPANY.phone2Tel],
  sameAs: [COMPANY.instagramUrl],
  address: {
    "@type": "PostalAddress",
    streetAddress: COMPANY.street,
    addressLocality: COMPANY.city,
    addressRegion: COMPANY.state,
    postalCode: COMPANY.cep,
    addressCountry: "BR",
  },
};

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { name: "theme-color", content: "#0B0E18" },
      { title: "AÇOS DIAMONDS — Excelência em aço inox" },
      { name: "description", content: "Fabricação de soluções em aço inox sob medida." },
      { property: "og:site_name", content: "AÇOS DIAMONDS" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "icon", href: "/favicon.ico", type: "image/x-icon" },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      { rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;700&family=Montserrat:wght@600;700;800&display=swap" },
    ],
    scripts: [{ type: "application/ld+json", children: JSON.stringify(orgLd) }],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="pt-BR">
      <head><HeadContent /></head>
      <body>{children}<Scripts /></body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();
  return (
    <QueryClientProvider client={queryClient}>
      <SiteHeader />
      <main><Outlet /></main>
      <SiteFooter />
      <WhatsAppFloat />
    </QueryClientProvider>
  );
}
