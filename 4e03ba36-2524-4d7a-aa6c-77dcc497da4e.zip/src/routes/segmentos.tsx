import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { CtaBand, PageHero } from "@/components/site/parts";
import { categories, img, productsOf } from "@/data/catalog";
import { breadcrumbLd, seo } from "@/lib/site";

export const Route = createFileRoute("/segmentos")({
  head: () => ({
    ...seo({
      title: "Soluções por Segmento em Aço Inox | AÇOS DIAMONDS",
      description: "Soluções em aço inox para hospitais e farma, acessibilidade, mobiliário, longarinas, cozinhas industriais e projetos industriais especiais.",
      path: "/segmentos",
    }),
    scripts: [breadcrumbLd([{ name: "Início", path: "/" }, { name: "Soluções por segmento", path: "/segmentos" }])],
  }),
  component: Segmentos,
});

function Segmentos() {
  return (
    <>
      <PageHero image={img("hero-industria")} alt="Indústria em aço inox"
        crumbs={[{ label: "Início", to: "/" }, { label: "Soluções por segmento" }]}
        eyebrow="Segmentos atendidos" title="Soluções por segmento"
        text="Desenvolvemos soluções em aço inox sob medida para hospitais, laboratórios, indústrias, cozinhas industriais e projetos especiais." />
      {categories.map((c, i) => (
        <section key={c.slug} className={i % 2 ? "section-dark" : ""}>
          <div className="container-site grid items-center gap-10 py-14 md:grid-cols-2 md:py-20">
            <img src={c.hero} alt={`${c.name} — aço inox`} loading="lazy" className={`aspect-[4/3] w-full rounded-lg object-cover shadow-card ${i % 2 ? "md:order-last" : ""}`} />
            <div>
              <p className="eyebrow">{c.tagline}</p>
              <h2 className="diamond-line mt-2 text-2xl font-extrabold uppercase md:text-3xl">{c.name}</h2>
              <p className={`mt-5 ${i % 2 ? "text-navy-foreground/75" : "text-muted-foreground"}`}>{c.intro}</p>
              <ul className="mt-5 flex flex-wrap gap-2">
                {productsOf(c.slug).slice(0, 6).map((p) => (
                  <li key={p.slug}>
                    <Link to="/produtos/$categoria/$produto" params={{ categoria: c.slug, produto: p.slug }}
                      className={`inline-block rounded-full border px-3 py-1.5 text-xs hover:border-primary ${i % 2 ? "border-navy-foreground/20" : "bg-card"}`}>{p.name}</Link>
                  </li>
                ))}
              </ul>
              <Button asChild variant={i % 2 ? "hero" : "solid"} size="xl" className="mt-8">
                <Link to="/produtos/$categoria" params={{ categoria: c.slug }}>Conhecer soluções</Link>
              </Button>
            </div>
          </div>
        </section>
      ))}
      <CtaBand />
    </>
  );
}
