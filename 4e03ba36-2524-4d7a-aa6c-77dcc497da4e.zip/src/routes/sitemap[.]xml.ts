import { createFileRoute } from "@tanstack/react-router";
import { categories, products } from "@/data/catalog";
import { SITE_URL } from "@/lib/site";

export const Route = createFileRoute("/sitemap.xml")({
  server: {
    handlers: {
      GET: () => {
        const paths = ["/", "/sobre", "/produtos", "/segmentos", "/projetos-especiais", "/contato", "/orcamento",
          ...categories.map((c) => `/produtos/${c.slug}`),
          ...products.filter((p) => p.published).map((p) => `/produtos/${p.category}/${p.slug}`)];
        const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${paths
          .map((p) => `<url><loc>${SITE_URL}${p}</loc></url>`).join("")}</urlset>`;
        return new Response(xml, { headers: { "Content-Type": "application/xml" } });
      },
    },
  },
});
