import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import { CtaBand, PageHero } from "@/components/site/parts";
import { categories, img, productsOf } from "@/data/catalog";
import { breadcrumbLd, seo } from "@/lib/site";

export const Route = createFileRoute("/produtos/")({
  head: () => ({
    ...seo({
      title: "Catálogo de Produtos em Aço Inox | AÇOS DIAMONDS",
      description: "Catálogo digital: equipamentos hospitalares, barras de acessibilidade, cadeiras, longarinas, cozinha industrial e projetos especiais em aço inox.",
      path: "/produtos",
    }),
    scripts: [breadcrumbLd([{ name: "Início", path: "/" }, { name: "Produtos", path: "/produtos" }])],
  }),
  component: Produtos,
});

function Produtos() {
  return (
    <>
      <PageHero image={img("fabrica-interior")} alt="Fábrica de equipamentos em aço inox"
        crumbs={[{ label: "Início", to: "/" }, { label: "Produtos" }]}
        eyebrow="Catálogo digital" title="Produtos em aço inox"
        text="Explore nossas linhas de produtos organizadas por categoria." />
      <section className="container-site grid gap-6 py-16 md:grid-cols-2 md:py-24">
        {categories.map((c) => {
          const items = productsOf(c.slug);
          return (
            <Link key={c.slug} to="/produtos/$categoria" params={{ categoria: c.slug }}
              className="group grid overflow-hidden rounded-lg border bg-card shadow-card transition hover:border-primary/40 sm:grid-cols-[2fr_3fr]">
              <img src={c.hero} alt={c.name} loading="lazy" className="aspect-[16/9] h-full w-full object-cover sm:aspect-auto" />
              <div className="flex flex-col p-6">
                <p className="eyebrow">{items.length} produtos</p>
                <h2 className="mt-2 text-xl font-extrabold uppercase">{c.name}</h2>
                <p className="mt-2 flex-1 text-sm text-muted-foreground">{c.short}</p>
                <span className="mt-4 inline-flex items-center gap-1 font-display text-xs font-bold uppercase tracking-wider text-primary">
                  Ver categoria <ArrowRight className="size-3.5 transition-transform group-hover:translate-x-1" />
                </span>
              </div>
            </Link>
          );
        })}
      </section>
      <CtaBand />
    </>
  );
}
