import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";
import { LeadForm } from "@/components/site/LeadForm";
import { PageHero } from "@/components/site/parts";
import { img } from "@/data/catalog";
import { seo } from "@/lib/site";

export const Route = createFileRoute("/orcamento")({
  validateSearch: z.object({ produto: z.string().max(150).optional(), segmento: z.string().max(80).optional() }),
  head: () => seo({
    title: "Solicitar Orçamento | AÇOS DIAMONDS — Aço Inox",
    description: "Solicite um orçamento de equipamentos, mobiliário ou projetos em aço inox sob medida com a AÇOS DIAMONDS.",
    path: "/orcamento",
  }),
  component: Orcamento,
});

function Orcamento() {
  const { produto, segmento } = Route.useSearch();
  return (
    <>
      <PageHero image={img("solda-laser-cta")} alt="Solda laser em aço inox"
        crumbs={[{ label: "Início", to: "/" }, { label: "Solicitar orçamento" }]}
        eyebrow="Atendimento comercial" title="Solicitar orçamento"
        text="Preencha o formulário e nossa equipe entrará em contato com a melhor solução para você." />
      <section className="container-site max-w-3xl py-14 md:py-20">
        <LeadForm kind="orcamento" product={produto} defaultSegment={segmento} withFiles />
      </section>
    </>
  );
}
