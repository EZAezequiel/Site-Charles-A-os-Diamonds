import { createFileRoute } from "@tanstack/react-router";
import { CtaBand, PageHero, SectionTitle } from "@/components/site/parts";
import { img } from "@/data/catalog";
import { breadcrumbLd, seo } from "@/lib/site";
import { DIFERENCIAIS } from "@/data/diferenciais";

export const Route = createFileRoute("/sobre")({
  head: () => ({
    ...seo({
      title: "Sobre a AÇOS DIAMONDS | Fabricante em Aço Inox desde 2017",
      description: "Conheça a AÇOS DIAMONDS: desenvolvimento e fabricação de soluções em aço inox com corte a laser, dobra CNC, solda laser e fabricação sob medida.",
      path: "/sobre",
    }),
    scripts: [breadcrumbLd([{ name: "Início", path: "/" }, { name: "Sobre nós", path: "/sobre" }])],
  }),
  component: Sobre,
});

const PROCESSOS = [
  { title: "Corte a laser", text: "Recortes precisos em chapas de aço inox, garantindo encaixes perfeitos e acabamento limpo.", image: "hero-solda-laser" },
  { title: "Dobra CNC", text: "Conformação controlada por CNC para peças com dimensões exatas e repetibilidade.", image: "fabrica-interior" },
  { title: "Solda laser", text: "Junções resistentes e de alto padrão estético, ideais para ambientes que exigem higiene.", image: "solda-laser-cta" },
  { title: "Fabricação sob medida", text: "Cada projeto é desenvolvido de acordo com as especificações e a rotina do cliente.", image: "tanques-industriais" },
];

function Sobre() {
  return (
    <>
      <PageHero
        image={img("hero-industria")} alt="Indústria com equipamentos em aço inox"
        crumbs={[{ label: "Início", to: "/" }, { label: "Sobre nós" }]}
        eyebrow="Quem somos" title="Excelência em aço inox desde 2017."
        text="Desenvolvemos soluções em aço inox sob medida, com qualidade, precisão e agilidade para cada projeto."
      />
      <section className="container-site grid gap-10 py-16 md:grid-cols-2 md:py-24">
        <SectionTitle eyebrow="Nossa atuação" title="Especialistas em soluções em aço inox" />
        <div className="space-y-4 text-muted-foreground">
          <p>A AÇOS DIAMONDS atua no desenvolvimento e fabricação de equipamentos e estruturas em aço inox que atendem às necessidades de diferentes segmentos: hospitais, clínicas, laboratórios, indústrias, cozinhas industriais e projetos especiais.</p>
          <p>Unimos tecnologia de produção, engenharia e acabamento premium para entregar produtos resistentes, duráveis e de fácil higienização — do mobiliário hospitalar às linhas de produção industriais.</p>
        </div>
      </section>
      <section className="section-dark py-16 md:py-24">
        <div className="container-site">
          <SectionTitle light eyebrow="Processos produtivos" title="Tecnologia aplicada ao aço inox" />
          <div className="mt-10 grid gap-6 md:grid-cols-2">
            {PROCESSOS.map((p) => (
              <article key={p.title} className="overflow-hidden rounded-lg border border-navy-foreground/10 bg-navy-2">
                <img src={img(p.image)} alt={`${p.title} — processo produtivo em aço inox`} loading="lazy" className="aspect-[16/9] w-full object-cover" />
                <div className="p-6">
                  <h3 className="text-lg font-bold uppercase">{p.title}</h3>
                  <p className="mt-2 text-sm text-navy-foreground/75">{p.text}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
      <section className="container-site py-16 md:py-24">
        <SectionTitle eyebrow="Nossos diferenciais" title="Por que a AÇOS DIAMONDS" />
        <div className="mt-10 grid grid-cols-2 gap-4 md:grid-cols-3">
          {DIFERENCIAIS.map((d) => (
            <div key={d.title} className="rounded-lg border bg-card p-5 shadow-card">
              <d.icon className="size-7 text-primary" strokeWidth={1.5} />
              <h3 className="mt-3 font-display text-sm font-bold uppercase">{d.title}</h3>
            </div>
          ))}
        </div>
      </section>
      <CtaBand />
    </>
  );
}
