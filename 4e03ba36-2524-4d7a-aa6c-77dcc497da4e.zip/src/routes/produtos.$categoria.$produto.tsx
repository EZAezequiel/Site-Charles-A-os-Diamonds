import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { CheckCircle2, MessageCircle, Share2 } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Breadcrumbs, CtaBand, ProductCard } from "@/components/site/parts";
import { getCategory, getProduct, productsOf } from "@/data/catalog";
import { breadcrumbLd, seo, SITE_URL, whatsappUrl } from "@/lib/site";

export const Route = createFileRoute("/produtos/$categoria/$produto")({
  loader: ({ params }) => {
    const category = getCategory(params.categoria);
    const product = getProduct(params.categoria, params.produto);
    if (!category || !product) throw notFound();
    return { category, product };
  },
  head: ({ loaderData }) => {
    if (!loaderData) return { meta: [{ title: "Produto não encontrado | AÇOS DIAMONDS" }, { name: "robots", content: "noindex" }] };
    const { product: p, category: c } = loaderData;
    const path = `/produtos/${c.slug}/${p.slug}`;
    return {
      ...seo({
        title: p.seoTitle ?? `${p.name} em Aço Inox — ${c.name} | AÇOS DIAMONDS`,
        description: p.seoDescription ?? `${p.name} em aço inox. ${p.description}`.slice(0, 160),
        path, type: "product",
      }),
      scripts: [
        breadcrumbLd([{ name: "Início", path: "/" }, { name: "Produtos", path: "/produtos" }, { name: c.name, path: `/produtos/${c.slug}` }, { name: p.name, path }]),
        { type: "application/ld+json", children: JSON.stringify({
          "@context": "https://schema.org", "@type": "Product", name: p.name, description: p.description,
          category: c.name, brand: { "@type": "Brand", name: "AÇOS DIAMONDS" }, url: `${SITE_URL}${path}`,
        }) },
      ],
    };
  },
  component: ProductPage,
});

function ProductPage() {
  const { product: p, category: c } = Route.useLoaderData();
  const [copied, setCopied] = useState(false);
  const related = productsOf(c.slug).filter((o) => o.slug !== p.slug).slice(0, 4);

  async function share() {
    const url = window.location.href;
    if (navigator.share) {
      try { await navigator.share({ title: p.name, url }); } catch { /* cancelado */ }
    } else {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  }

  return (
    <>
      <section className="section-dark">
        <div className="container-site py-5">
          <Breadcrumbs items={[{ label: "Início", to: "/" }, { label: "Produtos", to: "/produtos" }, { label: c.name, to: "/produtos/$categoria", params: { categoria: c.slug } }, { label: p.name }]} />
        </div>
      </section>
      <section className="container-site grid gap-10 py-10 md:grid-cols-2 md:py-16">
        <div className="flex aspect-square items-center justify-center rounded-lg border bg-card p-6 shadow-card md:p-10">
          <img src={p.image} alt={`${p.name} em aço inox — AÇOS DIAMONDS`} className="max-h-full max-w-full object-contain" />
        </div>
        <div>
          <Link to="/produtos/$categoria" params={{ categoria: c.slug }} className="eyebrow hover:underline">{c.name}</Link>
          <h1 className="mt-2 text-3xl font-extrabold uppercase leading-tight md:text-4xl">{p.name}</h1>
          <p className="mt-5 text-lg text-muted-foreground">{p.description}</p>
          <h2 className="mt-8 font-display text-sm font-bold uppercase tracking-wider">Características e diferenciais</h2>
          <ul className="mt-4 space-y-3">
            {p.features.map((f) => (
              <li key={f} className="flex gap-3"><CheckCircle2 className="mt-0.5 size-5 shrink-0 text-primary" />{f}</li>
            ))}
          </ul>
          <div className="mt-10 flex flex-col gap-3 sm:flex-row sm:flex-wrap">
            <Button asChild variant="hero" size="xl">
              <Link to="/orcamento" search={{ produto: p.name, segmento: c.name }}>Solicitar orçamento</Link>
            </Button>
            <Button asChild variant="whatsapp" size="xl">
              <a href={whatsappUrl(`Olá! Conheci a AÇOS DIAMONDS pelo site e gostaria de um orçamento para: ${p.name}.`)} target="_blank" rel="noopener noreferrer"><MessageCircle /> WhatsApp</a>
            </Button>
            <Button variant="outline" size="xl" onClick={share}><Share2 /> {copied ? "Link copiado!" : "Compartilhar"}</Button>
          </div>
        </div>
      </section>
      {related.length > 0 && (
        <section className="container-site pb-16">
          <h2 className="diamond-line text-xl font-extrabold uppercase">Mais em {c.name}</h2>
          <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {related.map((r) => <ProductCard key={r.slug} p={r} />)}
          </div>
        </section>
      )}
      <CtaBand />
    </>
  );
}
