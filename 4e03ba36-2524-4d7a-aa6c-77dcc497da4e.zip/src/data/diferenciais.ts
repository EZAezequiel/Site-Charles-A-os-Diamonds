import { Layers, Ruler, ScanLine, Sparkles, Truck, Zap } from "lucide-react";
export const DIFERENCIAIS = [
  { icon: ScanLine, title: "Corte a laser", text: "Precisão em cada peça de aço inox." },
  { icon: Layers, title: "Dobra CNC", text: "Dobras exatas e repetíveis." },
  { icon: Zap, title: "Solda laser", text: "Junções limpas e resistentes." },
  { icon: Ruler, title: "Fabricação sob medida", text: "Projetos conforme sua especificação." },
  { icon: Sparkles, title: "Acabamento premium", text: "Superfícies lisas e polidas." },
  { icon: Truck, title: "Atendimento nacional", text: "Atendemos clientes em todo o Brasil." },
];
