// Catálogo AÇOS DIAMONDS — conteúdo extraído do catálogo oficial.
// Para adicionar um produto, inclua um item em `products` com a categoria correspondente.
const images = import.meta.glob("../assets/img/*.webp", { eager: true, import: "default" }) as Record<string, string>;
export const img = (name: string) => images[`../assets/img/${name}.webp`] ?? "";

export type CategorySlug =
  | "hospitalar-e-farma"
  | "acessibilidade"
  | "cadeiras"
  | "longarinas"
  | "cozinha-industrial"
  | "projetos-especiais";

export interface Category {
  slug: CategorySlug;
  name: string;
  short: string;
  tagline: string;
  intro: string;
  highlights: string[];
  applications?: string[];
  hero: string;
  seoTitle: string;
  seoDescription: string;
}

export interface Product {
  slug: string;
  name: string;
  category: CategorySlug;
  description: string;
  features: string[];
  image: string;
  published: boolean;
  seoTitle?: string;
  seoDescription?: string;
}

export const categories: Category[] = [
  {
    slug: "hospitalar-e-farma",
    name: "Hospitalar e Farma",
    short: "Equipamentos e mobiliário hospitalar em aço inox para ambientes que exigem máxima higiene.",
    tagline: "Soluções para ambientes que exigem máxima higiene, resistência e segurança.",
    intro:
      "Linha completa de equipamentos hospitalares em aço inox: armários, carrinhos, macas, cadeiras e acessórios desenvolvidos para rotinas hospitalares intensivas, com fácil higienização e alta resistência.",
    highlights: ["Aço inox de alta qualidade", "Fácil higienização", "Alta resistência", "Conforme normas", "Segurança", "Funcionalidade"],
    hero: img("hospitalar-hero"),
    seoTitle: "Equipamentos Hospitalares em Aço Inox | AÇOS DIAMONDS",
    seoDescription:
      "Mobiliário hospitalar em inox: armários, carrinhos, macas, cadeiras de coleta, hampers e portas. Fabricante de equipamentos hospitalares sob medida.",
  },
  {
    slug: "acessibilidade",
    name: "Acessibilidade",
    short: "Barras, corrimãos e guarda-corpos em inox para segurança e autonomia.",
    tagline: "Acessibilidade, conforto e segurança no dia a dia.",
    intro:
      "Barras e acessórios em aço inox que garantem acessibilidade, conforto e segurança, além de soluções de mobilidade e proteção como divisores de fluxo, bate-rodas e guarda-corpos.",
    highlights: ["Segurança", "Autonomia", "Durabilidade", "Soluções personalizadas"],
    hero: img("acessibilidade-hero"),
    seoTitle: "Barras de Acessibilidade em Inox e Guarda-Corpos | AÇOS DIAMONDS",
    seoDescription:
      "Barras de acessibilidade em inox (fixa, articulada, em L), corrimãos, guarda-corpos e bate-rodas. Segurança e autonomia com acabamento premium.",
  },
  {
    slug: "cadeiras",
    name: "Cadeiras",
    short: "Cadeiras em aço inox ergonômicas, resistentes e fáceis de limpar.",
    tagline: "Design moderno, conforto e durabilidade.",
    intro:
      "A combinação entre design moderno, conforto e durabilidade. Cadeiras em aço inox ideais para ambientes que exigem higiene, segurança e alto padrão de qualidade, com modelos de acordo com a NR17.",
    highlights: ["Economia", "Resistência", "Sofisticação", "De acordo com a NR17"],
    hero: img("cadeiras-hero"),
    seoTitle: "Cadeiras em Aço Inox com Regulagem de Altura (NR17) | AÇOS DIAMONDS",
    seoDescription:
      "Cadeiras inox para laboratórios, hospitais e indústrias, com regulagem de altura de 530 mm a 730 mm de acordo com a NR17.",
  },
  {
    slug: "longarinas",
    name: "Longarinas",
    short: "Longarinas em inox para recepções e salas de espera de alto fluxo.",
    tagline: "Resistência, conforto e design contemporâneo.",
    intro:
      "Projetadas para ambientes de alto fluxo, unem resistência, conforto e design contemporâneo. Ideais para recepções, hospitais, clínicas, laboratórios e áreas de espera que exigem durabilidade e fácil higienização.",
    highlights: ["Estrutura reforçada", "Aço inox premium", "Longa vida útil", "Conforto"],
    applications: ["Hospitais", "Clínicas", "Laboratórios", "Recepções", "Salas de espera", "Ambientes institucionais"],
    hero: img("longarinas-hero"),
    seoTitle: "Longarinas Hospitalares em Aço Inox | AÇOS DIAMONDS",
    seoDescription:
      "Longarinas em inox de 3 e 4 lugares e estofadas para hospitais, clínicas, laboratórios e salas de espera. Estrutura reforçada e fácil limpeza.",
  },
  {
    slug: "cozinha-industrial",
    name: "Cozinha Industrial",
    short: "Bancadas, gabinetes, coifas e equipamentos em inox para cozinhas profissionais.",
    tagline: "Segurança alimentar e limpeza mais eficiente.",
    intro:
      "A utilização do aço inox na cozinha industrial contribui para a segurança alimentar, uma vez que o material é menos suscetível à contaminação e permite uma limpeza mais eficiente.",
    highlights: ["Aço inox premium", "Fácil limpeza e manutenção", "Alta durabilidade", "Resistência", "Aplicação profissional"],
    hero: img("cozinha-industrial-hero"),
    seoTitle: "Cozinha Industrial em Aço Inox: Bancadas e Coifas | AÇOS DIAMONDS",
    seoDescription:
      "Bancadas industriais em inox, gabinetes com cuba, coifas, estantes, tanques, caixas de gordura, grelhas e carrinhos para cozinhas profissionais.",
  },
  {
    slug: "projetos-especiais",
    name: "Projetos Especiais",
    short: "Equipamentos industriais em inox desenvolvidos sob medida para sua operação.",
    tagline: "Projetos personalizados para necessidades específicas.",
    intro:
      "Estamos prontos para desenvolver projetos personalizados que atendam às suas necessidades específicas, com a garantia de um serviço excepcional e resultados surpreendentes.",
    highlights: ["Fabricação sob medida", "Construção reforçada", "Aço inox premium", "Movimentação eficiente"],
    hero: img("solucoes-especiais-hero"),
    seoTitle: "Projetos Especiais e Equipamentos Industriais em Inox | AÇOS DIAMONDS",
    seoDescription:
      "Fabricação de equipamentos industriais em aço inox sob medida: tanques, esteiras transportadoras, linhas de moagem, túneis transportadores e temperadeiras.",
  },
];

const P = (
  category: CategorySlug,
  slug: string,
  name: string,
  description: string,
  features: string[],
  image = slug,
): Product => ({ category, slug, name, description, features, image: img(image), published: true });

export const products: Product[] = [
  // Hospitalar e Farma
  P("hospitalar-e-farma", "armarios-hospitalares-inox", "Armários", "Durabilidade e acabamento superior para rotinas hospitalares intensivas.", ["Estrutura reforçada em aço inox", "Acabamento de alta qualidade", "Portas com fechamento seguro"]),
  P("hospitalar-e-farma", "carrinho-transporte-inox", "Carrinho de transporte", "Resistência e qualidade construtiva em cada detalhe.", ["Aço inox 304", "Portas com fechamento seguro", "Mobilidade e estabilidade"]),
  P("hospitalar-e-farma", "banheira-hospitalar-recem-nascido", "Banheira hospitalar para recém-nascido", "Aço inox de alta qualidade com acabamento durável e higiênico.", ["Material seguro e higiênico", "Design anatômico e confortável", "Fácil movimentação e praticidade"]),
  P("hospitalar-e-farma", "carrinhos-auxiliares-curativos", "Carrinhos auxiliares para curativos", "Produção em aço inox com foco em resistência e fácil conservação.", ["Aço inox 304", "Estrutura resistente e funcional", "Rodízios de alta performance"]),
  P("hospitalar-e-farma", "hamper-com-amortecedor", "Hamper com amortecedor", "Permite higienização frequente sem risco de oxidação.", ["Estrutura reforçada em aço inox", "Superfície lisa e polida, facilita a limpeza", "Rodízios resistentes"]),
  P("hospitalar-e-farma", "banco-inox-regulagem-altura", "Banco inox com regulagem de altura", "Estrutura robusta em aço inox com excelente resistência ao uso diário.", ["Aço inox 304", "Fácil de limpar, garantindo higiene", "Mobilidade e estabilidade"]),
  P("hospitalar-e-farma", "cadeira-banho-higienica", "Cadeira de banho higiênica", "Possui assento largo e estrutura reforçada para maior segurança.", ["Material seguro e higiênico", "Suporta até 150 kg", "Rodas giratórias com freios"]),
  P("hospitalar-e-farma", "cadeira-coleta-sangue", "Cadeira de coleta de sangue", "Uso ideal para procedimentos como coleta de sangue ou aplicação de injeções.", ["Braçadeiras com regulagem de altura", "Aço inoxidável com ponteiras de borracha", "Assento e encosto estofados"]),
  P("hospitalar-e-farma", "beliche-solteiro-reforcada", "Beliche solteiro reforçada", "Robusta e resistente, atende bem ambientes que exigem camas para descanso.", ["Design moderno que economiza espaço", "Estrutura resistente e funcional", "Compatível com colchões padrão solteiro"]),
  P("hospitalar-e-farma", "maca-exames-transporte", "Maca de exames e transporte", "Possui uma estrutura em aço inoxidável e estofado preto com cabeceira ajustável.", ["Design ergonômico", "Fácil de limpar e esterilizar", "Cabeceira reclinável"]),
  P("hospitalar-e-farma", "gabinete-com-gavetas", "Gabinete com gavetas", "Resistente, fácil de limpar e projetado para otimizar o espaço.", ["Material seguro e higiênico", "Alta durabilidade", "Fácil movimentação e praticidade"]),
  P("hospitalar-e-farma", "porta-dupla-inox", "Porta dupla", "Em aço inox, permite uma limpeza rápida, eficiente e durável, essencial para o controle de contaminação.", ["Visores de vidro para controle visual", "Barras horizontais para facilitar a abertura", "Evita a propagação de bactérias"]),
  // Acessibilidade
  P("acessibilidade", "barra-fixa-inox", "Barra fixa", "Barra de apoio em aço inox para ambientes acessíveis.", ["Segurança", "Autonomia", "Durabilidade"]),
  P("acessibilidade", "barra-articulada-inox", "Barra articulada", "Barra de apoio articulada em aço inox para ambientes acessíveis.", ["Segurança", "Autonomia", "Durabilidade"]),
  P("acessibilidade", "barra-em-l-inox", "Barra em L", "Barra de apoio em L em aço inox para ambientes acessíveis.", ["Segurança", "Autonomia", "Durabilidade"]),
  P("acessibilidade", "barra-articulada-modelo-2", "Barra articulada (modelo 2)", "Modelo articulado em aço inox apresentado no catálogo de acessibilidade.", ["Segurança", "Autonomia", "Durabilidade"]),
  P("acessibilidade", "barra-em-l-modelo-2", "Barra em L (modelo 2)", "Modelo de barra em aço inox apresentado no catálogo de acessibilidade.", ["Segurança", "Autonomia", "Durabilidade"]),
  P("acessibilidade", "divisor-de-fluxo", "Divisor de fluxo", "Solução de mobilidade e proteção em aço inox: segurança, funcionalidade e design.", ["Segurança", "Autonomia", "Soluções personalizadas"]),
  P("acessibilidade", "bate-rodas", "Bate-rodas", "Solução de mobilidade e proteção em aço inox: segurança, funcionalidade e design.", ["Segurança", "Autonomia", "Soluções personalizadas"]),
  P("acessibilidade", "guarda-corpo-corrimao", "Guarda-corpo e corrimão", "Guarda-corpo com corrimão em aço inox: segurança, funcionalidade e design.", ["Segurança", "Autonomia", "Soluções personalizadas"]),
  P("acessibilidade", "guarda-corpo-aco-galvanizado", "Guarda-corpo em aço galvanizado", "Guarda-corpo em aço galvanizado para áreas externas e acessos.", ["Segurança", "Autonomia", "Soluções personalizadas"]),
  P("acessibilidade", "guarda-corpo-vidro-corrimao", "Guarda-corpo com vidro e corrimão", "Guarda-corpo com vidro e corrimão: segurança, funcionalidade e design.", ["Segurança", "Autonomia", "Soluções personalizadas"]),
  // Cadeiras
  P("cadeiras", "cadeira-inox", "Cadeira inox", "Resistente, fácil de limpar e projetada para otimizar o espaço. Modelo de acordo com a NR17.", ["Aço inox de alta qualidade", "Acabamento polido", "Resistente à corrosão", "Alta resistência", "Assento anatômico", "Encosto ergonômico", "Apoio para os pés"]),
  P("cadeiras", "cadeira-inox-regulagem-altura", "Cadeira inox com regulagem de altura", "Altura padrão segundo a NR17 para balcão médio: para trabalhos em balcões com altura entre 700 mm e 900 mm, a altura do assento deve ser ajustável entre 530 mm (mínima) e 730 mm (máxima).", ["Regulagem de altura de 530 mm a 730 mm", "De acordo com a NR17", "Apoio para os pés", "Rodízios"]),
  // Longarinas
  P("longarinas", "longarina-3-lugares", "Longarina de 3 lugares", "Oferece conforto, resistência e excelente durabilidade para ambientes de alto fluxo.", ["Material seguro e de fácil limpeza", "Alta durabilidade", "Alta resistência"], "longarina-3-e-4-lugares"),
  P("longarinas", "longarina-4-lugares", "Longarina de 4 lugares", "Oferece conforto, resistência e excelente durabilidade para ambientes de alto fluxo.", ["Material seguro e de fácil limpeza", "Alta durabilidade", "Alta resistência"], "longarina-3-e-4-lugares"),
  P("longarinas", "longarina-estofada", "Longarina estofada", "Solução ideal para ambientes que necessitam acomodar mais usuários com segurança e conforto.", ["Material seguro e de fácil limpeza", "Alta durabilidade", "Alta resistência"]),
  // Cozinha industrial
  P("cozinha-industrial", "armario-estante-cozinha-industrial", "Armários e estantes", "Oferecem organização, resistência e máxima higiene para ambientes profissionais.", ["Estrutura reforçada em aço inox", "Superfície lisa e polida, facilita a limpeza", "Prateleiras amplas para otimização de espaço"]),
  P("cozinha-industrial", "gabinete-com-cuba-inox", "Gabinete", "Com cuba, integra bancada funcional, armazenamento prático e qualidade para uso intensivo.", ["Aço inox 304", "Amplo armazenamento", "Cuba integrada"]),
  P("cozinha-industrial", "bancada-lisa-ou-com-cuba", "Bancada lisa ou com cuba", "Opção com cuba ou lisa, é a escolha ideal para quem busca um equipamento profissional e resistente.", ["Aço inox premium", "Fácil limpeza e higienização", "Prateleira reforçada"]),
  P("cozinha-industrial", "bancada-inox-cubas", "Bancada", "Ideal para preparo, lavagem e apoio de atividades em cozinhas industriais, laboratórios e áreas técnicas.", ["Estrutura reforçada", "Facilita a limpeza diária", "Cubas funcionais"]),
  P("cozinha-industrial", "carrinho-auxiliar-cozinha", "Carrinho auxiliar", "Combina mobilidade, resistência e praticidade para otimizar a rotina operacional.", ["Estrutura reforçada em aço inox", "Superfície lisa e polida, facilita a limpeza", "Prateleiras amplas para otimização de espaço"]),
  P("cozinha-industrial", "coifa-inox", "Coifa", "Para captação eficiente de vapores, fumaça e calor, proporcionando mais segurança, conforto e higiene.", ["Aço inox 304", "Exaustão eficiente", "Acabamento profissional"]),
  P("cozinha-industrial", "tanque-caixa-gordura", "Tanques e caixas de gordura", "Fabricados em aço inox de alta qualidade, oferecem excelente durabilidade, fácil limpeza e desempenho.", ["Aço inox premium", "Estrutura durável", "Alta funcionalidade"]),
  P("cozinha-industrial", "grelha-inox", "Grelhas", "Desenvolvida para sistemas de drenagem e escoamento em cozinhas industriais.", ["Estrutura reforçada", "Facilita a limpeza diária", "Cesto interno removível"]),
  // Projetos especiais
  P("projetos-especiais", "tanques-industriais", "Tanques", "Ideal para processos industriais que exigem controle de temperatura, qualidade e confiabilidade operacional.", ["Aço inox premium", "Superfície lisa e polida, facilita a limpeza", "Opções com rodízios"]),
  P("projetos-especiais", "esteira-transportadora", "Esteira transportadora", "Ideal para ambientes industriais que exigem eficiência operacional e fácil higienização.", ["Estrutura reforçada", "Fácil limpeza e manutenção", "Movimentação eficiente e organizada"]),
  P("projetos-especiais", "linha-de-moagem", "Linha de moagem", "Fabricada em aço de alta resistência, ideal para linha de produção.", ["Material seguro e de fácil limpeza", "Aço inox premium", "Construção reforçada"]),
  P("projetos-especiais", "tunel-transportador", "Túnel transportador", "Em aço inox, oferece transporte contínuo e seguro de produtos em linhas de produção.", ["Estrutura reforçada", "Fácil limpeza e manutenção", "Movimentação eficiente e organizada"]),
  P("projetos-especiais", "temperadeira", "Temperadeira", "Excelente desempenho para confeitarias, chocolaterias e indústrias alimentícias que buscam produtividade e eficiência.", ["Material seguro e de fácil limpeza", "Aço inox premium", "Construção reforçada"]),
];

export const getCategory = (slug: string) => categories.find((c) => c.slug === slug);
export const productsOf = (slug: string) => products.filter((p) => p.category === slug && p.published);
export const getProduct = (cat: string, slug: string) =>
  products.find((p) => p.category === cat && p.slug === slug && p.published);
