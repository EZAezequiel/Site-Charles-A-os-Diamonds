export const SITE_URL = "https://acosdiamonds.lovable.app";
export const COMPANY = {
  name: "AÇOS DIAMONDS",
  street: "R. Comendador João Torquato Lazzarini, 562",
  district: "Vila Nova Bonsucesso",
  cep: "07175-060",
  city: "Guarulhos",
  state: "SP",
  phone1: "(11) 91364-4273",
  phone1Tel: "+5511913644273",
  phone2: "(11) 2467-1676",
  phone2Tel: "+551124671676",
  email: "acos.diamonds2025@gmail.com",
  instagram: "@acosdiamonds",
  instagramUrl: "https://www.instagram.com/acosdiamonds",
  cnpj: "37.849.051.0001/00",
};
export const WHATSAPP_MSG =
  "Olá! Conheci a AÇOS DIAMONDS pelo site e gostaria de solicitar informações sobre seus produtos e soluções.";
export const whatsappUrl = (msg = WHATSAPP_MSG) =>
  `https://wa.me/5511913644273?text=${encodeURIComponent(msg)}`;
export const MAP_QUERY = encodeURIComponent(
  "R. Comendador João Torquato Lazzarini, 562 - Vila Nova Bonsucesso, 07175-060",
);

export function seo(opts: { title: string; description: string; path: string; image?: string; type?: string }) {
  const url = `${SITE_URL}${opts.path}`;
  const meta: Array<Record<string, string>> = [
    { title: opts.title },
    { name: "description", content: opts.description },
    { property: "og:title", content: opts.title },
    { property: "og:description", content: opts.description },
    { property: "og:type", content: opts.type ?? "website" },
    { property: "og:url", content: url },
    { property: "og:locale", content: "pt_BR" },
    { name: "twitter:card", content: "summary_large_image" },
    { name: "twitter:title", content: opts.title },
    { name: "twitter:description", content: opts.description },
  ];
  return { meta, links: [{ rel: "canonical", href: url }] };
}

export const breadcrumbLd = (items: { name: string; path: string }[]) => ({
  type: "application/ld+json",
  children: JSON.stringify({
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: items.map((it, i) => ({
      "@type": "ListItem",
      position: i + 1,
      name: it.name,
      item: `${SITE_URL}${it.path}`,
    })),
  }),
});
