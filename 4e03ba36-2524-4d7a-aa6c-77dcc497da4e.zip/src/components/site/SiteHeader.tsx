import { Link } from "@tanstack/react-router";
import { Menu, X } from "lucide-react";
import { useEffect, useState } from "react";
import logo from "@/assets/img/logo-acos-diamonds.png";
import { Button } from "@/components/ui/button";

const NAV = [
  { to: "/", label: "Início" },
  { to: "/sobre", label: "Sobre nós" },
  { to: "/produtos", label: "Produtos" },
  { to: "/segmentos", label: "Soluções por segmento" },
  { to: "/projetos-especiais", label: "Projetos especiais" },
  { to: "/contato", label: "Contato" },
] as const;

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
  }, [open]);

  return (
    <header className="sticky top-0 z-50 border-b border-navy-foreground/10 bg-navy/90 text-navy-foreground backdrop-blur-md">
      <div className="container-site flex h-16 items-center justify-between gap-4 lg:h-20">
        <Link to="/" aria-label="AÇOS DIAMONDS — página inicial" onClick={() => setOpen(false)}>
          <img src={logo} alt="AÇOS DIAMONDS — Excelência em aço inox" className="h-10 w-auto lg:h-12" width={180} height={98} />
        </Link>
        <nav aria-label="Principal" className="hidden items-center gap-6 xl:flex">
          {NAV.map((n) => (
            <Link
              key={n.to}
              to={n.to}
              activeOptions={{ exact: n.to === "/" }}
              className="font-display text-[13px] font-semibold text-navy-foreground/80 transition-colors hover:text-cyan data-[status=active]:text-cyan"
            >
              {n.label}
            </Link>
          ))}
        </nav>
        <div className="flex items-center gap-2">
          <Button asChild variant="hero" size="sm" className="hidden h-10 px-5 sm:inline-flex">
            <Link to="/orcamento">Solicitar orçamento</Link>
          </Button>
          <button
            type="button"
            className="inline-flex h-11 w-11 items-center justify-center rounded-md border border-navy-foreground/20 xl:hidden"
            aria-label={open ? "Fechar menu" : "Abrir menu"}
            aria-expanded={open}
            onClick={() => setOpen((v) => !v)}
          >
            {open ? <X className="size-5" /> : <Menu className="size-5" />}
          </button>
        </div>
      </div>
      {open && (
        <div className="fixed inset-x-0 top-16 bottom-0 z-40 section-dark animate-rise overflow-y-auto xl:hidden">
          <nav aria-label="Menu móvel" className="container-site flex flex-col py-6">
            {NAV.map((n) => (
              <Link
                key={n.to}
                to={n.to}
                activeOptions={{ exact: n.to === "/" }}
                onClick={() => setOpen(false)}
                className="border-b border-navy-foreground/10 py-4 font-display text-lg font-semibold data-[status=active]:text-cyan"
              >
                {n.label}
              </Link>
            ))}
            <Button asChild variant="hero" size="xl" className="mt-6">
              <Link to="/orcamento" onClick={() => setOpen(false)}>Solicitar orçamento</Link>
            </Button>
          </nav>
        </div>
      )}
    </header>
  );
}
