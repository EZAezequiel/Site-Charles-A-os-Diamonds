import { Link } from "@tanstack/react-router";
import { ArrowRight, ChevronRight, MessageCircle } from "lucide-react";
import type { ReactNode } from "react";
import { Button } from "@/components/ui/button";
import type { Product } from "@/data/catalog";
import { whatsappUrl } from "@/lib/site";

export function WhatsAppFloat() {
  return (
    <a
      href={whatsappUrl()}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Falar no WhatsApp"
      className="fixed right-4 bottom-4 z-40 inline-flex h-14 w-14 items-center justify-center rounded-full bg-whatsapp text-whatsapp-foreground shadow-glow transition-transform hover:scale-105 md:right-6 md:bottom-6"
    >
      <MessageCircle className="size-7" />
    </a>
  );
}

export function Breadcrumbs({ items }: { items: { label: string; to?: string; params?: Record<string, string> }[] }) {
  return (
    <nav aria-label="Breadcrumb" className="text-xs text-metal">
      <ol className="flex flex-wrap items-center gap-1">
        {items.map((it, i) => (
          <li key={i} className="flex items-center gap-1">
            {i > 0 && <ChevronRight className="size-3" />}
            {it.to ? (
              // eslint-disable-next-line @typescript-eslint/no-explicit-any
              <Link to={it.to as any} params={it.params as any} className="hover:text-cyan">{it.label}</Link>
            ) : (
              <span aria-current="page" className="text-navy-foreground">{it.label}</span>
            )}
          </li>
        ))}
      </ol>
    </nav>
  );
}

export function PageHero({ eyebrow, title, text, image, alt, crumbs, children }: {
  eyebrow?: string; title: string; text?: string; image: string; alt: string;
  crumbs?: Parameters<typeof Breadcrumbs>[0]["items"]; children?: ReactNode;
}) {
  return (
    <section className="section-dark relative overflow-hidden">
      <img src={image} alt={alt} className="absolute inset-0 h-full w-full object-cover opacity-60" />
      <div className="hero-fade absolute inset-0" />
      <div className="container-site relative py-14 md:py-24">
        {crumbs && <Breadcrumbs items={crumbs} />}
        {eyebrow && <p className="eyebrow mt-6">{eyebrow}</p>}
        <h1 className="mt-3 max-w-3xl text-3xl font-extrabold uppercase leading-tight md:text-5xl animate-rise">{title}</h1>
        {text && <p className="mt-5 max-w-2xl text-base text-navy-foreground/80 md:text-lg">{text}</p>}
        {children && <div className="mt-8 flex flex-col gap-3 sm:flex-row">{children}</div>}
      </div>
    </section>
  );
}

export function ProductCard({ p }: { p: Product }) {
  return (
    <Link
      to="/produtos/$categoria/$produto"
      params={{ categoria: p.category, produto: p.slug }}
      className="group flex flex-col overflow-hidden rounded-lg border bg-card shadow-card transition-all hover:-translate-y-1 hover:border-primary/40"
    >
      <div className="flex aspect-[4/3] items-center justify-center bg-card p-4">
        <img src={p.image} alt={`${p.name} em aço inox — AÇOS DIAMONDS`} loading="lazy" className="max-h-full max-w-full object-contain transition-transform duration-500 group-hover:scale-105" />
      </div>
      <div className="flex flex-1 flex-col border-t p-5">
        <h3 className="font-display text-base font-bold uppercase">{p.name}</h3>
        <p className="mt-2 line-clamp-2 flex-1 text-sm text-muted-foreground">{p.description}</p>
        <span className="mt-4 inline-flex items-center gap-1 font-display text-xs font-bold uppercase tracking-wider text-primary">
          Ver detalhes <ArrowRight className="size-3.5 transition-transform group-hover:translate-x-1" />
        </span>
      </div>
    </Link>
  );
}

export function CtaBand() {
  return (
    <section className="section-dark grid-lines relative overflow-hidden">
      <div className="container-site relative py-16 text-center md:py-24">
        <h2 className="mx-auto max-w-3xl text-2xl font-extrabold uppercase leading-tight md:text-4xl">
          Vamos <span className="text-steel">transformar</span> seu projeto em realidade?
        </h2>
        <p className="mx-auto mt-4 max-w-xl text-navy-foreground/75">
          Entre em contato com nossa equipe e descubra como podemos desenvolver a solução ideal para sua necessidade.
        </p>
        <div className="mt-8 flex flex-col justify-center gap-3 sm:flex-row">
          <Button asChild variant="whatsapp" size="xl">
            <a href={whatsappUrl()} target="_blank" rel="noopener noreferrer"><MessageCircle /> Falar no WhatsApp</a>
          </Button>
          <Button asChild variant="outlineLight" size="xl">
            <Link to="/orcamento">Solicitar orçamento</Link>
          </Button>
        </div>
      </div>
    </section>
  );
}

export function SectionTitle({ eyebrow, title, text, light }: { eyebrow?: string; title: string; text?: string; light?: boolean }) {
  return (
    <div className="max-w-2xl">
      {eyebrow && <p className="eyebrow">{eyebrow}</p>}
      <h2 className="diamond-line mt-2 text-2xl font-extrabold uppercase leading-tight md:text-4xl">{title}</h2>
      {text && <p className={`mt-5 ${light ? "text-navy-foreground/75" : "text-muted-foreground"}`}>{text}</p>}
    </div>
  );
}
