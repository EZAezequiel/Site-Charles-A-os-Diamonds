import { Link } from "@tanstack/react-router";
import { Instagram, Mail, MapPin, Phone } from "lucide-react";
import logo from "@/assets/img/logo-acos-diamonds.png";
import { categories } from "@/data/catalog";
import { COMPANY, whatsappUrl } from "@/lib/site";

export function SiteFooter() {
  return (
    <footer className="section-dark grid-lines border-t border-navy-foreground/10">
      <div className="container-site grid gap-10 py-14 md:grid-cols-2 lg:grid-cols-4">
        <div>
          <img src={logo} alt="AÇOS DIAMONDS" className="h-14 w-auto" loading="lazy" />
          <p className="mt-4 max-w-xs text-sm text-metal">
            Soluções em aço inox sob medida para hospitais, laboratórios, indústrias, cozinhas industriais e projetos especiais.
          </p>
          <p className="mt-4 text-xs text-metal/70">CNPJ {COMPANY.cnpj}</p>
        </div>
        <div>
          <h2 className="eyebrow">Produtos</h2>
          <ul className="mt-4 space-y-2 text-sm">
            {categories.map((c) => (
              <li key={c.slug}>
                <Link to="/produtos/$categoria" params={{ categoria: c.slug }} className="text-navy-foreground/80 hover:text-cyan">
                  {c.name}
                </Link>
              </li>
            ))}
          </ul>
        </div>
        <div>
          <h2 className="eyebrow">Empresa</h2>
          <ul className="mt-4 space-y-2 text-sm">
            <li><Link to="/sobre" className="text-navy-foreground/80 hover:text-cyan">Sobre nós</Link></li>
            <li><Link to="/segmentos" className="text-navy-foreground/80 hover:text-cyan">Soluções por segmento</Link></li>
            <li><Link to="/projetos-especiais" className="text-navy-foreground/80 hover:text-cyan">Projetos especiais</Link></li>
            <li><Link to="/orcamento" className="text-navy-foreground/80 hover:text-cyan">Solicitar orçamento</Link></li>
            <li><Link to="/contato" className="text-navy-foreground/80 hover:text-cyan">Contato</Link></li>
          </ul>
        </div>
        <div>
          <h2 className="eyebrow">Fale conosco</h2>
          <ul className="mt-4 space-y-3 text-sm text-navy-foreground/80">
            <li className="flex gap-2"><MapPin className="mt-0.5 size-4 shrink-0 text-cyan" />{COMPANY.street}, {COMPANY.district} — CEP {COMPANY.cep}</li>
            <li className="flex gap-2"><Phone className="mt-0.5 size-4 shrink-0 text-cyan" />
              <span><a href={whatsappUrl()} target="_blank" rel="noopener noreferrer" className="hover:text-cyan">{COMPANY.phone1}</a><br />
              <a href={`tel:${COMPANY.phone2Tel}`} className="hover:text-cyan">{COMPANY.phone2}</a></span></li>
            <li className="flex gap-2"><Mail className="mt-0.5 size-4 shrink-0 text-cyan" /><a href={`mailto:${COMPANY.email}`} className="break-all hover:text-cyan">{COMPANY.email}</a></li>
            <li className="flex gap-2"><Instagram className="mt-0.5 size-4 shrink-0 text-cyan" /><a href={COMPANY.instagramUrl} target="_blank" rel="noopener noreferrer" className="hover:text-cyan">{COMPANY.instagram}</a></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-navy-foreground/10 py-5 text-center text-xs text-metal/70">
        © {new Date().getFullYear()} AÇOS DIAMONDS — Excelência em aço inox.
      </div>
    </footer>
  );
}
