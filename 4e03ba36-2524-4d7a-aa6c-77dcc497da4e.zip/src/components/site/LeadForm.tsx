import { useState } from "react";
import { z } from "zod";
import { CheckCircle2, Loader2, Paperclip } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";

const schema = z.object({
  name: z.string().trim().min(2, "Informe seu nome").max(120),
  company: z.string().trim().max(120).optional(),
  phone: z.string().trim().min(8, "Informe um telefone válido").max(30),
  email: z.string().trim().email("E-mail inválido").max(200),
  segment: z.string().trim().max(80).optional(),
  message: z.string().trim().min(5, "Descreva sua necessidade").max(4000),
});

const SEGMENTS = ["Hospitalar e Farma", "Acessibilidade", "Cadeiras", "Longarinas", "Cozinha Industrial", "Projetos Especiais", "Outro"];
const field = "mt-1.5 w-full rounded-md border border-input bg-card px-3.5 py-3 text-base outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/20";
const label = "font-display text-xs font-bold uppercase tracking-wider text-foreground/80";

export function LeadForm({ kind, product, withFiles, defaultSegment }: {
  kind: "contato" | "orcamento" | "projeto"; product?: string | undefined; withFiles?: boolean; defaultSegment?: string | undefined;
}) {
  const [status, setStatus] = useState<"idle" | "sending" | "done">("idle");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [files, setFiles] = useState<File[]>([]);
  const [fail, setFail] = useState("");

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setFail("");
    const fd = new FormData(e.currentTarget);
    if (fd.get("website")) return; // honeypot
    const parsed = schema.safeParse(Object.fromEntries(fd));
    if (!parsed.success) {
      setErrors(Object.fromEntries(parsed.error.issues.map((i) => [i.path[0] as string, i.message])));
      return;
    }
    if (files.length > 5 || files.some((f) => f.size > 15 * 1024 * 1024)) {
      setErrors({ files: "Até 5 arquivos de no máximo 15 MB cada." });
      return;
    }
    setErrors({});
    setStatus("sending");
    try {
      const paths: string[] = [];
      for (const f of files) {
        const path = `${crypto.randomUUID()}/${f.name.replace(/[^\w.-]+/g, "_")}`;
        const { error } = await supabase.storage.from("lead-attachments").upload(path, f);
        if (error) throw error;
        paths.push(path);
      }
      const d = parsed.data;
      const { error } = await supabase.from("leads").insert({
        kind, name: d.name, company: d.company || null, phone: d.phone, email: d.email,
        segment: d.segment || null, product: product ?? null, message: d.message, attachments: paths,
      });
      if (error) throw error;
      setStatus("done");
    } catch {
      setStatus("idle");
      setFail("Não foi possível enviar agora. Tente novamente ou fale conosco pelo WhatsApp.");
    }
  }

  if (status === "done") {
    return (
      <div className="rounded-lg border bg-card p-8 text-center shadow-card">
        <CheckCircle2 className="mx-auto size-12 text-primary" />
        <h3 className="mt-4 text-xl font-bold uppercase">Solicitação enviada!</h3>
        <p className="mt-2 text-muted-foreground">Recebemos suas informações. Nossa equipe entrará em contato em breve.</p>
      </div>
    );
  }

  const err = (k: string) => errors[k] && <p className="mt-1 text-sm text-destructive">{errors[k]}</p>;

  return (
    <form onSubmit={onSubmit} noValidate className="grid gap-5 rounded-lg border bg-card p-5 shadow-card sm:grid-cols-2 md:p-8">
      <input type="text" name="website" tabIndex={-1} autoComplete="off" className="hidden" aria-hidden />
      <div><label className={label} htmlFor="name">Nome *</label><input id="name" name="name" autoComplete="name" className={field} />{err("name")}</div>
      <div><label className={label} htmlFor="company">Empresa</label><input id="company" name="company" autoComplete="organization" className={field} /></div>
      <div><label className={label} htmlFor="phone">Telefone / WhatsApp *</label><input id="phone" name="phone" type="tel" inputMode="tel" autoComplete="tel" className={field} />{err("phone")}</div>
      <div><label className={label} htmlFor="email">E-mail *</label><input id="email" name="email" type="email" inputMode="email" autoComplete="email" className={field} />{err("email")}</div>
      <div className="sm:col-span-2"><label className={label} htmlFor="segment">Segmento</label>
        <select id="segment" name="segment" defaultValue={defaultSegment ?? ""} className={field}>
          <option value="">Selecione</option>
          {SEGMENTS.map((s) => <option key={s}>{s}</option>)}
        </select>
      </div>
      {product && <p className="text-sm text-muted-foreground sm:col-span-2">Produto: <strong className="text-foreground">{product}</strong></p>}
      <div className="sm:col-span-2"><label className={label} htmlFor="message">{kind === "projeto" ? "Descrição da necessidade *" : "Mensagem *"}</label>
        <textarea id="message" name="message" rows={5} className={field} />{err("message")}</div>
      {withFiles && (
        <div className="sm:col-span-2">
          <span className={label}>Arquivos ou desenhos técnicos</span>
          <label className="mt-1.5 flex cursor-pointer items-center gap-3 rounded-md border border-dashed border-input bg-muted px-4 py-4 text-sm text-muted-foreground hover:border-primary">
            <Paperclip className="size-5 text-primary" />
            {files.length ? files.map((f) => f.name).join(", ") : "Anexar arquivos (PDF, DWG, imagens — até 5, 15 MB cada)"}
            <input type="file" multiple className="sr-only" accept=".pdf,.dwg,.dxf,.step,.stp,.png,.jpg,.jpeg,.webp,.zip"
              onChange={(e) => setFiles(Array.from(e.target.files ?? []))} />
          </label>
          {err("files")}
        </div>
      )}
      {fail && <p className="text-sm text-destructive sm:col-span-2">{fail}</p>}
      <Button type="submit" variant="hero" size="xl" className="sm:col-span-2" disabled={status === "sending"}>
        {status === "sending" ? <><Loader2 className="animate-spin" /> Enviando…</> : "Enviar solicitação"}
      </Button>
    </form>
  );
}
