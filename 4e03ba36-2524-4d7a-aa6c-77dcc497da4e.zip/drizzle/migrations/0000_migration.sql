CREATE TABLE public.leads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at timestamptz NOT NULL DEFAULT now(),
  kind text NOT NULL DEFAULT 'contato',
  name text NOT NULL,
  company text,
  phone text NOT NULL,
  email text NOT NULL,
  segment text,
  product text,
  message text NOT NULL,
  attachments text[] NOT NULL DEFAULT '{}'
);
GRANT INSERT ON public.leads TO anon, authenticated;
GRANT ALL ON public.leads TO service_role;
ALTER TABLE public.leads ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can submit a lead" ON public.leads FOR INSERT TO anon, authenticated
WITH CHECK (char_length(name) BETWEEN 2 AND 120 AND char_length(email) <= 200 AND char_length(phone) BETWEEN 8 AND 30 AND char_length(message) BETWEEN 5 AND 4000 AND kind IN ('contato','orcamento','projeto') AND coalesce(array_length(attachments,1),0) <= 5);
CREATE POLICY "Anyone can upload lead attachments" ON storage.objects FOR INSERT TO anon, authenticated
WITH CHECK (bucket_id = 'lead-attachments');