<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Project rules
- Product catalog lives in `src/data/catalog.ts` (categories + products with slug, SEO, published flag); pages and sitemap derive from it, so add products there only.
- Catalog photos are crops from the client's PDF stored as `src/assets/img/<slug>.webp`, resolved via `img(name)`; never use stock photos as product photos.
- Form submissions go to the `leads` table (insert-only for visitors) with files in the private `lead-attachments` bucket.
